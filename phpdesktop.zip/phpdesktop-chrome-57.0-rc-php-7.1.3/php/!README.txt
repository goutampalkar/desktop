PHP binaries downloaded from windows.php.net.
