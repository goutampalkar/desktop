Login/Signup modal window
=========

Front-end coded version of a modal window to login/signup into your website. Once opened, the user can easily switch from one form to the other, or select the reset password option.

[Article on CodyHouse](https://codyhouse.co/gem/loginsignup-modal-window/)

[Demo](https://codyhouse.co/demo/login-signup-modal-window/)
 
[Terms](https://codyhouse.co/terms/)

Icons: [Nucleo](https://nucleoapp.com/)